import { randomUUID } from 'node:crypto'

export type Currency = 'USD' | 'NGN'
export type WalletStatus = 'ACTIVE' | 'LOCKED'
export type EntryKind = 'DEPOSIT' | 'WITHDRAWAL' | 'TRANSFER_IN' | 'TRANSFER_OUT' | 'REVERSAL'
export type LedgerEntry = { id: string; walletId: string; kind: EntryKind; amountMinor: number; currency: Currency; reference: string; createdAt: string }
export type Wallet = { id: string; ownerId: string; currency: Currency; availableMinor: number; pendingMinor: number; status: WalletStatus; createdAt: string }

const wallets = new Map<string, Wallet>()
const ledger: LedgerEntry[] = []
const idempotency = new Map<string, unknown>()

function seed() {
  if (wallets.has('wallet_demo')) return
  const wallet: Wallet = { id: 'wallet_demo', ownerId: 'demo-user', currency: 'USD', availableMinor: 425000, pendingMinor: 0, status: 'ACTIVE', createdAt: new Date().toISOString() }
  wallets.set(wallet.id, wallet)
  ledger.push({ id: randomUUID(), walletId: wallet.id, kind: 'DEPOSIT', amountMinor: 425000, currency: 'USD', reference: 'demo-seed', createdAt: new Date().toISOString() })
}
seed()

export function getWallet(ownerId = 'demo-user') {
  return [...wallets.values()].find((wallet) => wallet.ownerId === ownerId) ?? createWallet(ownerId, 'USD')
}

export function createWallet(ownerId: string, currency: Currency) {
  const wallet: Wallet = { id: randomUUID(), ownerId, currency, availableMinor: 0, pendingMinor: 0, status: 'ACTIVE', createdAt: new Date().toISOString() }
  wallets.set(wallet.id, wallet)
  return wallet
}

export function getLedger(walletId: string) { return ledger.filter((entry) => entry.walletId === walletId).slice(-30).reverse() }

export function creditWallet(walletId: string, amountMinor: number, reference: string, kind: EntryKind = 'DEPOSIT', key?: string) {
  if (key && idempotency.has(key)) return idempotency.get(key) as Wallet
  if (!Number.isInteger(amountMinor) || amountMinor <= 0) throw new Error('Amount must be a positive integer in minor units')
  const wallet = wallets.get(walletId)
  if (!wallet) throw new Error('Wallet not found')
  if (wallet.status !== 'ACTIVE') throw new Error('Wallet is locked')
  wallet.availableMinor += amountMinor
  ledger.push({ id: randomUUID(), walletId, kind, amountMinor, currency: wallet.currency, reference, createdAt: new Date().toISOString() })
  if (key) idempotency.set(key, wallet)
  return wallet
}

export function debitWallet(walletId: string, amountMinor: number, reference: string, kind: EntryKind = 'WITHDRAWAL', key?: string) {
  if (key && idempotency.has(key)) return idempotency.get(key) as Wallet
  if (!Number.isInteger(amountMinor) || amountMinor <= 0) throw new Error('Amount must be a positive integer in minor units')
  const wallet = wallets.get(walletId)
  if (!wallet) throw new Error('Wallet not found')
  if (wallet.status !== 'ACTIVE') throw new Error('Wallet is locked')
  if (wallet.availableMinor < amountMinor) throw new Error('Insufficient available balance')
  wallet.availableMinor -= amountMinor
  ledger.push({ id: randomUUID(), walletId, kind, amountMinor, currency: wallet.currency, reference, createdAt: new Date().toISOString() })
  if (key) idempotency.set(key, wallet)
  return wallet
}

export function formatMoney(minor: number, currency = 'USD') { return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(minor / 100) }

export const walletStore = { getWallet, getLedger, creditWallet, debitWallet }
