# DRIVE INVEST

Private two-role investment dashboard blueprint and starter codebase.

## Status
This package is a **sandbox-first implementation scaffold**. Real payment, KYC, FX, bank, and investment-provider integrations are intentionally disabled until legitimate credentials, provider authorization, security testing, reconciliation, and applicable compliance review are complete.

## Roles
- INVESTOR: one private investor account
- ADMIN: one administrator

## Build route
v0 → GitHub → Supabase → Vercel → sandbox payment/KYC/FX → authorized production providers

## Core financial rule
The frontend is never the authority for money. The ledger and confirmed provider events are authoritative.

## Project structure
- `app/` — Next.js route structure
- `src/components/` — UI modules
- `src/lib/` — service/domain layers
- `supabase/migrations/` — database migrations
- `docs/` — complete product blueprint and roadmap

## Local setup
1. Install Node.js and npm.
2. Install dependencies.
3. Copy `.env.example` to `.env.local`.
4. Configure sandbox Supabase credentials.
5. Run the Next.js development server.

Do not commit secrets.
