# DRIVE INVEST — COMPLETE PRODUCT SPECIFICATION

A private two-role investment dashboard with a simple investor experience and a single administrator.

### Investor
- Registration and email verification
- KYC workflow
- $500 disclosed activation requirement
- USD wallet with a $10,000 maximum
- Deposit and withdrawal
- Verified withdrawal account
- Investment view
- Transactions
- Notifications
- AI assistant
- Michael B. Jordan public updates
- Profile/security

### Administrator
- Investor management
- USD wallet and ledger
- NGN wallet
- USD/NGN conversion
- KYC review
- Deposits/withdrawals
- Investment/provider management
- Notifications
- Audit logs
- Reconciliation
- Settings

### Financial architecture
Frontend → backend → authorization → business logic → ledger → external provider → provider confirmation → ledger finalization → notification.

### Production constraint
Payment, KYC, FX and investment integrations remain sandbox/mock until legitimate credentials, authorization, security testing, reconciliation and applicable compliance review are complete.
