# DRIVE INVEST — BUILD ROADMAP & BLUEPRINT

## Phase 0 — Product
Investor: registration, OTP/email verification, KYC, profile, USD wallet, deposit, investment, withdrawal, verified withdrawal account, AI assistant, notifications, Michael B. Jordan public updates.

Admin: dashboard, investor management, KYC review, USD wallet, NGN wallet, USD/NGN conversion, deposits, withdrawals, investment management, external-provider transfers, notifications, audit logs, settings.

Initial limit: one investor + one administrator.

## Phase 1 — UX/UI
Investor navigation: Home, Wallet, Investment, Deposit, Withdraw, Transactions, Michael B. Jordan, AI Assistant, Notifications, Profile, Security.

Admin navigation: Overview, Investor, Wallets, Deposits, Withdrawals, Investment, USD/NGN, KYC, External Integrations, Notifications, Audit Logs, Settings.

## Phase 2 — Foundation
v0 → Next.js → GitHub → Vercel → Supabase. Maintain separate development, staging and production environments.

## Phase 3 — Database
Ledger is the financial source of truth. Do not overwrite wallet balances directly. Use recorded transactions and immutable ledger entries.

## Phase 4 — Authentication
Registration → email verification/OTP → password → login → session → MFA → authorization. Enforce roles at backend/database level.

## Phase 5 — KYC
NOT_STARTED → PENDING → REVIEW → VERIFIED, or REJECTED/EXPIRED. Use a real provider in production.

## Phase 6 — Ledger
Payment webhook → signature verification → duplicate check → transaction → ledger entries → balance calculation → audit event.

## Phase 7 — Activation
KYC → disclosed $500 activation requirement → payment → provider confirmation → activation. Never activate from frontend success alone.

## Phase 8 — Deposits
Create deposit → payment provider → webhook → verification → ledger → wallet → notification. Include idempotency, failures, refunds/reversals.

## Phase 9 — Withdrawals
Balance → KYC → withdrawal account → limits/risk → pending withdrawal → user confirmation → MFA/OTP → approval where required → provider → confirmation → ledger → notification.

## Phase 10 — Withdrawal account
Secure verification/tokenization, masked account display, additional verification when changed.

## Phase 11 — Admin + NGN
Admin-only NGN wallet and USD/NGN FX controls. Investor does not get NGN management.

## Phase 12 — External investment
Internal wallet → transfer request → authorization → provider API → provider confirmation → internal transaction. States: REQUESTED, PROCESSING, CONFIRMED, FAILED, REVERSED.

## Phase 13 — AI
Version 1 read-only. Version 2 prepares actions. AI never gets unrestricted financial authority.

## Phase 14 — Michael B. Jordan
Public sources → validation → news/event database → investor dashboard → notifications. No private scheduling or private-access claims.

## Phase 15 — Security
Test authentication, authorization, account takeover, duplicate payments, double withdrawals, negative balances, race conditions, webhook replay, manipulated amounts, FX errors, RLS and injection.

## Phase 16 — Reconciliation
Compare internal ledger with payment/bank/investment providers. Flag discrepancies instead of silently accepting them.

## Phase 17 — Staging
Test users, payments, KYC, withdrawals, webhooks and failures using sandbox providers.

## Phase 18 — Production readiness
Domain, HTTPS, database, backups, monitoring, error tracking, secrets, MFA, KYC/payment/FX/investment providers, webhooks, audit, reconciliation, terms, privacy, fee disclosures, withdrawal policy, compliance review.

## Phase 19 — Launch
Investor → authentication → KYC → $500 activation → wallet/investment → deposit/withdraw → ledger → reconciliation → audit.

## Phase 20 — Operations
Daily reconciliation and failure checks; weekly security/admin/backup checks; continuous fraud, uptime, API and unauthorized-access monitoring.

## Build order
01 specification → 02 UI/UX → 03 Next.js → 04 Supabase → 05 auth → 06 database → 07 KYC → 08 ledger → 09 wallet → 10 activation → 11 deposits → 12 withdrawal account → 13 withdrawals → 14 admin → 15 NGN/FX → 16 investment → 17 AI → 18 Michael B. Jordan → 19 security → 20 reconciliation → 21 staging → 22 compliance review → 23 production → 24 real-money activation.

## Core rule
Do not start with real money. Sandbox first.
