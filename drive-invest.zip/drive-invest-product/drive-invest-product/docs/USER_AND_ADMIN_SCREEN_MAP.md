# SCREEN MAP

## Investor
01 Welcome
02 Registration
03 Email OTP
04 Password
05 KYC
06 Terms & Disclosures
07 $500 Activation
08 Activation Confirmation
09 Home
10 Wallet
11 Deposit
12 Investment
13 Withdrawal Account
14 Withdraw
15 Transactions
16 Transaction Detail
17 AI Assistant
18 Michael B. Jordan Updates
19 Notifications
20 Profile
21 Security

## Admin
01 Admin Login
02 Overview
03 Investor
04 Investor Detail
05 USD Wallet
06 NGN Wallet
07 USD/NGN
08 Deposits
09 Withdrawals
10 Investment
11 KYC
12 External Integrations
13 Notifications
14 Audit Logs
15 Settings
16 Reconciliation
