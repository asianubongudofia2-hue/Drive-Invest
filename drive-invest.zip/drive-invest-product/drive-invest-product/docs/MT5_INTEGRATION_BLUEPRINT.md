# MT5 / AUTHORIZED INVESTMENT PROVIDER INTEGRATION BLUEPRINT

This document defines how an authorized MT5/broker or other investment provider may be integrated without making the frontend the financial authority.

Internal wallet
→ authorized transfer request
→ backend authorization
→ provider API
→ provider confirmation/webhook
→ internal ledger
→ reconciliation
→ audit log

Required provider states:
REQUESTED
PROCESSING
CONFIRMED
FAILED
REVERSED

Never mark an external transfer completed solely because an API call returned successfully.

For production, obtain the broker/provider's official API documentation, credentials, authorization and any required legal/compliance approval. Keep credentials server-side and verify webhooks/signatures.
