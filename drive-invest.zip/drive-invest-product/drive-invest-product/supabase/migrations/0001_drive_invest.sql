create extension if not exists "pgcrypto";

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'INVESTOR' check (role in ('ADMIN','INVESTOR')),
  created_at timestamptz not null default now()
);

create table if not exists wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  currency text not null check (currency in ('USD','NGN')),
  created_at timestamptz not null default now(),
  unique(user_id, currency)
);

create table if not exists ledger_accounts (
  id uuid primary key default gen_random_uuid(),
  wallet_id uuid references wallets(id),
  code text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique,
  user_id uuid references auth.users(id),
  type text not null,
  amount numeric(20,8) not null check (amount >= 0),
  currency text not null check (currency in ('USD','NGN')),
  status text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

create table if not exists ledger_entries (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null references transactions(id),
  account_id uuid not null references ledger_accounts(id),
  direction text not null check (direction in ('DEBIT','CREDIT')),
  amount numeric(20,8) not null check (amount > 0),
  currency text not null check (currency in ('USD','NGN')),
  created_at timestamptz not null default now()
);

create table if not exists kyc_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  status text not null default 'NOT_STARTED',
  provider_reference text,
  created_at timestamptz not null default now()
);

create table if not exists deposits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  transaction_id uuid references transactions(id),
  provider_reference text,
  status text not null,
  created_at timestamptz not null default now()
);

create table if not exists withdrawal_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  bank_name text,
  account_holder_name text,
  account_token text,
  masked_account text,
  status text not null default 'PENDING',
  created_at timestamptz not null default now()
);

create table if not exists withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  transaction_id uuid references transactions(id),
  withdrawal_account_id uuid references withdrawal_accounts(id),
  status text not null,
  created_at timestamptz not null default now()
);

create table if not exists investments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  amount numeric(20,8) not null default 0,
  currency text not null default 'USD',
  status text not null,
  created_at timestamptz not null default now()
);

create table if not exists investment_transfers (
  id uuid primary key default gen_random_uuid(),
  investment_id uuid references investments(id),
  provider_reference text,
  status text not null,
  created_at timestamptz not null default now()
);

create table if not exists exchange_rates (
  id uuid primary key default gen_random_uuid(),
  base_currency text not null,
  quote_currency text not null,
  rate numeric(20,8) not null,
  source text not null,
  observed_at timestamptz not null
);

create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  type text not null,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id),
  role text,
  action text not null,
  resource text,
  transaction_id uuid references transactions(id),
  result text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists ai_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists ai_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references ai_conversations(id),
  role text not null,
  content text not null,
  created_at timestamptz not null default now()
);

create table if not exists external_provider_accounts (
  id uuid primary key default gen_random_uuid(),
  provider_type text not null,
  status text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists webhook_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  external_event_id text not null,
  event_type text not null,
  processed_at timestamptz,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  unique(provider, external_event_id)
);

create table if not exists activation_payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  amount numeric(20,8) not null default 500,
  currency text not null default 'USD',
  status text not null default 'PENDING',
  provider_reference text,
  created_at timestamptz not null default now()
);
