export default function Home() {
  return (
    <main className="min-h-screen bg-slate-950 text-white p-8">
      <div className="mx-auto max-w-5xl">
        <p className="text-sm text-slate-400">SANDBOX MODE</p>
        <h1 className="mt-2 text-4xl font-semibold">Drive Invest</h1>
        <p className="mt-4 max-w-2xl text-slate-300">
          Private investment dashboard blueprint and sandbox-first application scaffold.
        </p>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-800 p-6">
            <h2 className="text-xl font-medium">Investor</h2>
            <p className="mt-2 text-slate-400">Wallet, investment, deposits, withdrawals, AI and public updates.</p>
          </div>
          <div className="rounded-2xl border border-slate-800 p-6">
            <h2 className="text-xl font-medium">Administrator</h2>
            <p className="mt-2 text-slate-400">USD/NGN controls, KYC, transactions, reconciliation and audit.</p>
          </div>
        </div>
      </div>
    </main>
  );
}
