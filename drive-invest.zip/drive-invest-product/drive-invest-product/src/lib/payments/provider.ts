export interface PaymentProvider {
  createPayment(input: { amount: string; currency: 'USD' | 'NGN'; reference: string }): Promise<{
    providerReference: string;
    status: 'PENDING' | 'PROCESSING';
  }>;
  getPaymentStatus(providerReference: string): Promise<string>;
  verifyWebhook(payload: string, signature: string): boolean;
}
