export const MAX_USD_WALLET = 10_000;
export const ACTIVATION_AMOUNT_USD = 500;

export function canCreditUsd(currentBalance: number, amount: number) {
  return currentBalance >= 0 && amount >= 0 && currentBalance + amount <= MAX_USD_WALLET;
}
