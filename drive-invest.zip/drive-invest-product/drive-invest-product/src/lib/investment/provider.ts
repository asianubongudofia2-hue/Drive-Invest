export interface InvestmentProvider {
  createTransfer(input: {
    userId: string;
    amount: string;
    currency: 'USD';
    reference: string;
  }): Promise<{ providerReference: string; status: 'REQUESTED' | 'PROCESSING' }>;
  getTransferStatus(providerReference: string): Promise<string>;
}
