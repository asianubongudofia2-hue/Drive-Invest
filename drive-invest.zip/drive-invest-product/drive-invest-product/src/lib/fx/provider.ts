export interface FXProvider {
  getUsdNgnRate(): Promise<{
    rate: string;
    source: string;
    timestamp: string;
  }>;
}
