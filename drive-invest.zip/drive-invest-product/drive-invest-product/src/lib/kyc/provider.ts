export type KycStatus =
  | 'NOT_STARTED' | 'PENDING' | 'REVIEW' | 'VERIFIED' | 'REJECTED' | 'EXPIRED';

export interface KycProvider {
  startVerification(input: { userId: string }): Promise<{ reference: string }>;
  getStatus(reference: string): Promise<KycStatus>;
}
