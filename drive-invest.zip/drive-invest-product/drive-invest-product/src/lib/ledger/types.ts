export type Currency = 'USD' | 'NGN';

export type LedgerEntry = {
  id: string;
  transactionId: string;
  accountId: string;
  currency: Currency;
  amount: string;
  direction: 'DEBIT' | 'CREDIT';
  createdAt: string;
};

export type TransactionStatus =
  | 'PENDING' | 'PROCESSING' | 'CONFIRMED' | 'COMPLETED'
  | 'FAILED' | 'CANCELLED' | 'REFUNDED' | 'REVERSED' | 'REJECTED';
