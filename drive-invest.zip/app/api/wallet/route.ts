import { NextResponse } from 'next/server'
import { creditWallet, debitWallet, getLedger, getWallet } from '@/lib/wallet'

export async function GET() {
  const wallet = getWallet()
  return NextResponse.json({ wallet, ledger: getLedger(wallet.id), mode: 'provider-disconnected' })
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as { action?: 'deposit' | 'withdraw'; amountMinor?: number; reference?: string; idempotencyKey?: string }
    if (body.action !== 'deposit' && body.action !== 'withdraw') return NextResponse.json({ error: 'Unsupported wallet action' }, { status: 400 })
    const wallet = getWallet()
    const reference = body.reference?.trim() || `${body.action}-${Date.now()}`
    const updated = body.action === 'deposit'
      ? creditWallet(wallet.id, body.amountMinor ?? 0, reference, 'DEPOSIT', body.idempotencyKey)
      : debitWallet(wallet.id, body.amountMinor ?? 0, reference, 'WITHDRAWAL', body.idempotencyKey)
    return NextResponse.json({ wallet: updated, ledger: getLedger(updated.id), simulated: true })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Wallet operation failed' }, { status: 400 })
  }
}
